

 <div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs12bbb.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs12bbb", "Pragmatic")' />
    <div class="slot-info-wrap">Bigger Bass Bonanza</div>
</div>

 <div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs20fparty2.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20fparty2", "Pragmatic")' />
    <div class="slot-info-wrap">Fruit Party 2</div>
</div>

 <div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs10floatdrg.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs10floatdrg", "Pragmatic")' />
    <div class="slot-info-wrap">Floating Dragon</div>
</div>

 <div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vswayshammthor.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vswayshammthor", "Pragmatic")' />
    <div class="slot-info-wrap">Power of Thor Megaways</div>
</div>

 <div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs20wildboost.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20wildboost", "Pragmatic")' />
    <div class="slot-info-wrap">Wild Booster</div>
</div>

 <div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs50juicyfr.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs50juicyfr", "Pragmatic")' />
    <div class="slot-info-wrap">Juicy Fruits</div>
</div>

 <div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs1024temuj.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs1024temuj", "Pragmatic")' />
    <div class="slot-info-wrap">Temujin Treasures</div>
</div>

 <div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs20olympgate.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20olympgate", "Pragmatic")' />
    <div class="slot-info-wrap">Gates of Olympus</div>
</div>

 <div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs20hburnhs.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20hburnhs", "Pragmatic")' />
    <div class="slot-info-wrap">Hot to Burn Hold and Spin</div>
</div>

 <div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs25jokerking.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25jokerking", "Pragmatic")' />
    <div class="slot-info-wrap">Joker King</div>
</div>

 <div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs20midas.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20midas", "Pragmatic")' />
    <div class="slot-info-wrap">The Hand of Midas</div>
</div>

 <div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs10eyestorm.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs10eyestorm", "Pragmatic")' />
    <div class="slot-info-wrap">Eye of the Storm</div>
</div>

 <div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vswaysmadame.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vswaysmadame", "Pragmatic")' />
    <div class="slot-info-wrap">Madame Destiny Megaways</div>
</div>

 <div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs5drmystery.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs5drmystery", "Pragmatic")' />
    <div class="slot-info-wrap">Dragon Kingdom Eyes of Fire</div>
</div>

 <div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs432congocash.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs432congocash", "Pragmatic")' />
    <div class="slot-info-wrap">Congo Cash</div>
</div>

 <div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs5aztecgems.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs5aztecgems", "Pragmatic")' />
    <div class="slot-info-wrap">Aztec Gems</div>
</div>

 <div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs5joker.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs5joker", "Pragmatic")' />
    <div class="slot-info-wrap">Joker's Jewels</div>
</div>

 <div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs20bonzgold.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20bonzgold", "Pragmatic")' />
    <div class="slot-info-wrap">Bonanza Gold</div>
</div>

 <div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs40wildwest.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs40wildwest", "Pragmatic")' />
    <div class="slot-info-wrap">Wild West Gold</div>
</div>

 <div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs20fruitsw.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20fruitsw", "Pragmatic")' />
    <div class="slot-info-wrap">Sweet Bonanza</div>
</div>

 <div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs9aztecgemsdx.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs9aztecgemsdx", "Pragmatic")' />
    <div class="slot-info-wrap">Aztec Gems Deluxe</div>
</div>

 <div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs10firestrike.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs10firestrike", "Pragmatic")' />
    <div class="slot-info-wrap">Fire Strike</div>
</div>

 <div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs10cowgold.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs10cowgold", "Pragmatic")' />
    <div class="slot-info-wrap">Cowboys Gold</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs20xmascarol.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20xmascarol", "Pragmatic")' />
    <div class="slot-info-wrap">Christmas Carol Megaways</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs10bbbonanza.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs10bbbonanza", "Pragmatic")' />
    <div class="slot-info-wrap">Big Bass Bonanza</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs20rhino.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20rhino", "Pragmatic")' />
    <div class="slot-info-wrap">Great Rhino</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs15diamond.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs15diamond", "Pragmatic")' />
    <div class="slot-info-wrap">Diamond Strike</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs20doghouse.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20doghouse", "Pragmatic")' />
    <div class="slot-info-wrap">The Dog House</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs20vegasmagic.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20vegasmagic", "Pragmatic")' />
    <div class="slot-info-wrap">Vegas Magic</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs10mayangods.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs10mayangods", "Pragmatic")' />
    <div class="slot-info-wrap">John Hunter And The Mayan Gods</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vswaysrhino.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vswaysrhino", "Pragmatic")' />
    <div class="slot-info-wrap">Great Rhino Megaways</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs1dragon8.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs1dragon8", "Pragmatic")' />
    <div class="slot-info-wrap">888 Dragons</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs20sbxmas.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20sbxmas", "Pragmatic")' />
    <div class="slot-info-wrap">Sweet Bonanza Xmas</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs40spartaking.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs40spartaking", "Pragmatic")' />
    <div class="slot-info-wrap">Spartan King</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vswaysdogs.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vswaysdogs", "Pragmatic")' />
    <div class="slot-info-wrap">The Dog House Megaways</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs20eightdragons.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20eightdragons", "Pragmatic")' />
    <div class="slot-info-wrap">8 Dragons</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs25scarabqueen.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25scarabqueen", "Pragmatic")' />
    <div class="slot-info-wrap">John Hunter and the Tomb of the Scarab Queen</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs243lionsgold.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs243lionsgold", "Pragmatic")' />
    <div class="slot-info-wrap">5 Lions Gold</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs7776aztec.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs7776aztec", "Pragmatic")' />
    <div class="slot-info-wrap">Aztec Bonanza</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs7fire88.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs7fire88", "Pragmatic")' />
    <div class="slot-info-wrap">Fire 88</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs243lions.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs243lions", "Pragmatic")' />
    <div class="slot-info-wrap">5 Lions</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs1masterjoker.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs1masterjoker", "Pragmatic")' />
    <div class="slot-info-wrap">Master Joker</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs25chilli.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25chilli", "Pragmatic")' />
    <div class="slot-info-wrap">Chilli Heat</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs25mustang.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25mustang", "Pragmatic")' />
    <div class="slot-info-wrap">Mustang Gold</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs4096bufking.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs4096bufking", "Pragmatic")' />
    <div class="slot-info-wrap">Buffalo King</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs25pandagold.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25pandagold", "Pragmatic")' />
    <div class="slot-info-wrap">Panda's Fortune</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs5ultra.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs5ultra", "Pragmatic")' />
    <div class="slot-info-wrap">Ultra Hold and Spin</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs20rhinoluxe.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20rhinoluxe", "Pragmatic")' />
    <div class="slot-info-wrap">Great Rhino Deluxe</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs75empress.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs75empress", "Pragmatic")' />
    <div class="slot-info-wrap">Golden Beauty</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs243dancingpar.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs243dancingpar", "Pragmatic")' />
    <div class="slot-info-wrap">Dance Party</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs20godiva.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20godiva", "Pragmatic")' />
    <div class="slot-info-wrap">Lady Godiva</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs25goldpig.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25goldpig", "Pragmatic")' />
    <div class="slot-info-wrap">Golden Pig</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs10fruity2.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs10fruity2", "Pragmatic")' />
    <div class="slot-info-wrap">Extra Juicy</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs25pyramid.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25pyramid", "Pragmatic")' />
    <div class="slot-info-wrap">Pyramid King</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs9madmonkey.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs9madmonkey", "Pragmatic")' />
    <div class="slot-info-wrap">Monkey Madness</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs243fortune.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs243fortune", "Pragmatic")' />
    <div class="slot-info-wrap">Caishen's Gold</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs25wildspells.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25wildspells", "Pragmatic")' />
    <div class="slot-info-wrap">Wild Spells</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs75bronco.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs75bronco", "Pragmatic")' />
    <div class="slot-info-wrap">Bronco Spirit</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs25wolfgold.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25wolfgold", "Pragmatic")' />
    <div class="slot-info-wrap">Wolf Gold</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs243caishien.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs243caishien", "Pragmatic")' />
    <div class="slot-info-wrap">Caishen's Cash</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs20goldfever.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20goldfever", "Pragmatic")' />
    <div class="slot-info-wrap">Gems Bonanza</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs20fruitparty.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20fruitparty", "Pragmatic")' />
    <div class="slot-info-wrap">Fruit Party</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs1ball.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs1ball", "Pragmatic")' />
    <div class="slot-info-wrap">Lucky Dragon Ball</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs576treasures.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs576treasures", "Pragmatic")' />
    <div class="slot-info-wrap">Wild Wild Riches</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs10bookoftut.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs10bookoftut", "Pragmatic")' />
    <div class="slot-info-wrap">Book of Tut</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs1fortunetree.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs1fortunetree", "Pragmatic")' />
    <div class="slot-info-wrap">Tree of Riches</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs5hotburn.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs5hotburn", "Pragmatic")' />
    <div class="slot-info-wrap">Hot to Burn</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs40pirate.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs40pirate", "Pragmatic")' />
    <div class="slot-info-wrap">Pirate Gold</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs25mmouse.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25mmouse", "Pragmatic")' />
    <div class="slot-info-wrap">Money Mouse</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs5super7.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs5super7", "Pragmatic")' />
    <div class="slot-info-wrap">Super 7s</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs1024lionsd.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs1024lionsd", "Pragmatic")' />
    <div class="slot-info-wrap">5 Lions Dance</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs25tigerwar.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25tigerwar", "Pragmatic")' />
    <div class="slot-info-wrap">The Tiger Warrior</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs5spjoker.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs5spjoker", "Pragmatic")' />
    <div class="slot-info-wrap">Super Joker</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs10returndead.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs10returndead", "Pragmatic")' />
    <div class="slot-info-wrap">Return of the Dead</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs10egyptcls.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs10egyptcls", "Pragmatic")' />
    <div class="slot-info-wrap">Ancient Egypt Classic</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs25newyear.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25newyear", "Pragmatic")' />
    <div class="slot-info-wrap">Lucky New Year</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs243mwarrior.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs243mwarrior", "Pragmatic")' />
    <div class="slot-info-wrap">Monkey Warrior</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs1money.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs1money", "Pragmatic")' />
    <div class="slot-info-wrap">Money Money Money</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs40pirgold.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs40pirgold", "Pragmatic")' />
    <div class="slot-info-wrap">Pirate Gold Deluxe</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs25journey.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25journey", "Pragmatic")' />
    <div class="slot-info-wrap">Journey to the West</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs243fortseren.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs243fortseren", "Pragmatic")' />
    <div class="slot-info-wrap">Greek Gods</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs25dragonkingdom.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25dragonkingdom", "Pragmatic")' />
    <div class="slot-info-wrap">Dragon Kingdom</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs10threestar.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs10threestar", "Pragmatic")' />
    <div class="slot-info-wrap">Three Star Fortune</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs1600drago.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs1600drago", "Pragmatic")' />
    <div class="slot-info-wrap">Drago - Jewels of Fortune</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs1024dtiger.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs1024dtiger", "Pragmatic")' />
    <div class="slot-info-wrap">The Dragon Tiger</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs20kraken.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20kraken", "Pragmatic")' />
    <div class="slot-info-wrap">Release the Kraken</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs25kingdoms.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25kingdoms", "Pragmatic")' />
    <div class="slot-info-wrap">3 Kingdoms -Battle of Red Cliffs</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs18mashang.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs18mashang", "Pragmatic")' />
    <div class="slot-info-wrap">Treasure Horse</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs1tigers.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs1tigers", "Pragmatic")' />
    <div class="slot-info-wrap">Triple Tigers</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs25goldrush.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25goldrush", "Pragmatic")' />
    <div class="slot-info-wrap">Gold Rush</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs40frrainbow.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs40frrainbow", "Pragmatic")' />
    <div class="slot-info-wrap">Fruit Rainbow</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs20bl.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20bl", "Pragmatic")' />
    <div class="slot-info-wrap">Busy Bees</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs50kingkong.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs50kingkong", "Pragmatic")' />
    <div class="slot-info-wrap">Mighty Kong</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs25dwarves_new.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25dwarves_new", "Pragmatic")' />
    <div class="slot-info-wrap">Dwarven Gold Deluxe</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs25asgard.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25asgard", "Pragmatic")' />
    <div class="slot-info-wrap">Asgard</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/cs5triple8gold.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/cs5triple8gold", "Pragmatic")' />
    <div class="slot-info-wrap">888 Gold</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs20egypttrs.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20egypttrs", "Pragmatic")' />
    <div class="slot-info-wrap">Egyptian Fortunes</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs40madwheel.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs40madwheel", "Pragmatic")' />
    <div class="slot-info-wrap">The Wild Machine</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs20hercpeg.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20hercpeg", "Pragmatic")' />
    <div class="slot-info-wrap">Hercules and Pegasus</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs20wildpix.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20wildpix", "Pragmatic")' />
    <div class="slot-info-wrap">Wild Pixies</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vswayshive.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vswayshive", "Pragmatic")' />
    <div class="slot-info-wrap">Star Bounty</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/cs3irishcharms.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/cs3irishcharms", "Pragmatic")' />
    <div class="slot-info-wrap">Irish Charms</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vswayswerewolf.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vswayswerewolf", "Pragmatic")' />
    <div class="slot-info-wrap">Curse of the Werewolf Megaways</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs25samurai.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25samurai", "Pragmatic")' />
    <div class="slot-info-wrap">Rise of Samurai</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs25bkofkngdm.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25bkofkngdm", "Pragmatic")' />
    <div class="slot-info-wrap">Book Of Kingdoms</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs25safari.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25safari", "Pragmatic")' />
    <div class="slot-info-wrap">Hot Safari</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs5ultrab.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs5ultrab", "Pragmatic")' />
    <div class="slot-info-wrap">Ultra Burn</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs50pixie.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs50pixie", "Pragmatic")' />
    <div class="slot-info-wrap">Pixie Wings</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs25peking.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25peking", "Pragmatic")' />
    <div class="slot-info-wrap">Peking Luck</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs20chicken.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20chicken", "Pragmatic")' />
    <div class="slot-info-wrap">The Great Chicken Escape</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs15fairytale.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs15fairytale", "Pragmatic")' />
    <div class="slot-info-wrap">Fairytale Fortune</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs7776secrets.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs7776secrets", "Pragmatic")' />
    <div class="slot-info-wrap">Aztec Treasure</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs9chen.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs9chen", "Pragmatic")' />
    <div class="slot-info-wrap">Master Chen's Fortune</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs5trjokers.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs5trjokers", "Pragmatic")' />
    <div class="slot-info-wrap">Triple Jokers</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs20eking.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20eking", "Pragmatic")' />
    <div class="slot-info-wrap">Emerald King</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs20honey.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20honey", "Pragmatic")' />
    <div class="slot-info-wrap">Honey Honey Honey</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs25walker.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25walker", "Pragmatic")' />
    <div class="slot-info-wrap">Wild Walker</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs25davinci.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25davinci", "Pragmatic")' />
    <div class="slot-info-wrap">Da Vinci's Treasure</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/cs3w.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/cs3w", "Pragmatic")' />
    <div class="slot-info-wrap">Diamonds are Forever 3 Lines</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs50chinesecharms.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs50chinesecharms", "Pragmatic")' />
    <div class="slot-info-wrap">Lucky Dragons</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs1fufufu.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs1fufufu", "Pragmatic")' />
    <div class="slot-info-wrap">Fu Fu Fu</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/cs5moneyroll.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/cs5moneyroll", "Pragmatic")' />
    <div class="slot-info-wrap">Money Roll</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs3train.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs3train", "Pragmatic")' />
    <div class="slot-info-wrap">Gold Train</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs9hotroll.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs9hotroll", "Pragmatic")' />
    <div class="slot-info-wrap">Hot Chilli</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs4096mystery.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs4096mystery", "Pragmatic")' />
    <div class="slot-info-wrap">Mysterious</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs13ladyofmoon.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs13ladyofmoon", "Pragmatic")' />
    <div class="slot-info-wrap">Lady of the Moon</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs5trdragons.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs5trdragons", "Pragmatic")' />
    <div class="slot-info-wrap">Triple Dragons</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs7monkeys.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs7monkeys", "Pragmatic")' />
    <div class="slot-info-wrap">7 Monkeys</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs25sea.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25sea", "Pragmatic")' />
    <div class="slot-info-wrap">Great Reef</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs117649starz.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs117649starz", "Pragmatic")' />
    <div class="slot-info-wrap">Starz Megaways</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs50safariking.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs50safariking", "Pragmatic")' />
    <div class="slot-info-wrap">Safari King</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs20santa.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20santa", "Pragmatic")' />
    <div class="slot-info-wrap">Santa</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs10vampwolf.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs10vampwolf", "Pragmatic")' />
    <div class="slot-info-wrap">Vampires vs Wolves</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs10madame.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs10madame", "Pragmatic")' />
    <div class="slot-info-wrap">Madame Destiny</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs8magicjourn.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs8magicjourn", "Pragmatic")' />
    <div class="slot-info-wrap">Magic Journey</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs25vegas.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25vegas", "Pragmatic")' />
    <div class="slot-info-wrap">Vegas Nights</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs20leprexmas.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20leprexmas", "Pragmatic")' />
    <div class="slot-info-wrap">Leprechaun Carol</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs40beowulf.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs40beowulf", "Pragmatic")' />
    <div class="slot-info-wrap">Beowulf</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs50aladdin.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs50aladdin", "Pragmatic")' />
    <div class="slot-info-wrap">3 Genie Wishes</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs7pigs.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs7pigs", "Pragmatic")' />
    <div class="slot-info-wrap">7 Piggies</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs25gladiator.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25gladiator", "Pragmatic")' />
    <div class="slot-info-wrap">Wild Gladiator</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs50hercules.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs50hercules", "Pragmatic")' />
    <div class="slot-info-wrap">Hercules</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs25queenofgold.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25queenofgold", "Pragmatic")' />
    <div class="slot-info-wrap">Queen of Gold</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs243crystalcave.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs243crystalcave", "Pragmatic")' />
    <div class="slot-info-wrap">Magic Crystals</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs20gorilla.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20gorilla", "Pragmatic")' />
    <div class="slot-info-wrap">Jungle Gorilla</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs40streetracer.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs40streetracer", "Pragmatic")' />
    <div class="slot-info-wrap">Street Racer</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs4096jurassic.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs4096jurassic", "Pragmatic")' />
    <div class="slot-info-wrap">Jurassic Giants</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs20leprechaun.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20leprechaun", "Pragmatic")' />
    <div class="slot-info-wrap">Leprechaun Song</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs50amt.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs50amt", "Pragmatic")' />
    <div class="slot-info-wrap">Aladdin's Treasure</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs10egypt.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs10egypt", "Pragmatic")' />
    <div class="slot-info-wrap">Ancient Egypt</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs20egypt.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20egypt", "Pragmatic")' />
    <div class="slot-info-wrap">Tales of Egypt</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs13g.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs13g", "Pragmatic")' />
    <div class="slot-info-wrap">Devil's 13</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs1024butterfly.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs1024butterfly", "Pragmatic")' />
    <div class="slot-info-wrap">Jade Butterfly</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs25dwarves.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25dwarves", "Pragmatic")' />
    <div class="slot-info-wrap">Dwarven Gold</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs25pantherqueen.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25pantherqueen", "Pragmatic")' />
    <div class="slot-info-wrap">Panther Queen</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs20aladdinsorc.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20aladdinsorc", "Pragmatic")' />
    <div class="slot-info-wrap">Aladdin and the Sorcerer</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs1024atlantis.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs1024atlantis", "Pragmatic")' />
    <div class="slot-info-wrap">Queen of Atlantis</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs20cm.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20cm", "Pragmatic")' />
    <div class="slot-info-wrap">Sugar Rush</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs20rome.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20rome", "Pragmatic")' />
    <div class="slot-info-wrap">Glorious Rome</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image"
    src="https://api.prerelease-env.biz/game_pic/rec/160/vs25romeoandjuliet.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25romeoandjuliet", "Pragmatic")' />
    <div class="slot-info-wrap">Romeo and Juliet</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs20cmv.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20cmv", "Pragmatic")' />
    <div class="slot-info-wrap">Sugar Rush Valentine's Day</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs15ktv.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs15ktv", "Pragmatic")' />
    <div class="slot-info-wrap">KTV</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs20cw.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20cw", "Pragmatic")' />
    <div class="slot-info-wrap">Sugar Rush Winter</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs15b.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs15b", "Pragmatic")' />
    <div class="slot-info-wrap">Crazy 7s</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs20hockey.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20hockey", "Pragmatic")' />
    <div class="slot-info-wrap">Hockey League</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs20gg.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20gg", "Pragmatic")' />
    <div class="slot-info-wrap">Spooky Fortune</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs25h.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25h", "Pragmatic")' />
    <div class="slot-info-wrap">Fruity Blast</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs9hockey.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs9hockey", "Pragmatic")' />
    <div class="slot-info-wrap">Hockey League Wild Match</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs25champ.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs25champ", "Pragmatic")' />
    <div class="slot-info-wrap">The Champions</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs20cms.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs20cms", "Pragmatic")' />
    <div class="slot-info-wrap">Sugar Rush Summer Time</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs9catz.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs9catz", "Pragmatic")' />
    <div class="slot-info-wrap">The Catfather</div>
</div>

<div class="slot-games-box" data-dom="slot-item" style="">
    <img style="width: 170px; height: 189px;" class="image" src="https://api.prerelease-env.biz/game_pic/rec/160/vs30catz.png"
    onclick='window.open("{{url('launchPragmaticSlots')}}/vs30catz", "Pragmatic")' />
    <div class="slot-info-wrap">The Catfather Part II</div>
</div>








<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>

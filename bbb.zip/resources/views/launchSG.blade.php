{!! $response !!}

<script>
    var href = document.querySelector('a').href;
    // alert('You will be redirected to the game lobby');
    window.location.replace(href);
</script>
